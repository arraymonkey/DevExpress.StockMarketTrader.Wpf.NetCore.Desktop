using System.Windows.Controls;

namespace DevExpress.StockMarketTrader.Wpf.Views {
    public partial class TradeHistoryView : UserControl {
        public TradeHistoryView() {
            InitializeComponent();
        }
    }
}
