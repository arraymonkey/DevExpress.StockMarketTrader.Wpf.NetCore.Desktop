using System.Windows.Controls;

namespace DevExpress.StockMarketTrader.Wpf.Views {
    public partial class TradesView : UserControl {
        public TradesView() {
            InitializeComponent();
        }
    }
}
