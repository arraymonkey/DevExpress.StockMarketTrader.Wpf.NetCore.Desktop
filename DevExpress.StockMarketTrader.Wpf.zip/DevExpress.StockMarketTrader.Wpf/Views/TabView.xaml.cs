using System.Windows.Controls;

namespace DevExpress.StockMarketTrader.Wpf.Views {
    public partial class TabView : UserControl {
        public TabView() {
            InitializeComponent();
        }
    }
}
