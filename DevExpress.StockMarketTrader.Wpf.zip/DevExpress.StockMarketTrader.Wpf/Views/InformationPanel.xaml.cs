using System.Windows.Controls;

namespace DevExpress.StockMarketTrader.Wpf.Views {
    public partial class InformationPanel : UserControl {
        public InformationPanel() {
            InitializeComponent();
        }
    }
}
