using System.Windows.Controls;

namespace DevExpress.StockMarketTrader.Wpf.Views {
    public partial class OrderHistoryView : UserControl {
        public OrderHistoryView() {
            InitializeComponent();
        }
    }
}
